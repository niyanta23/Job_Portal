﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
public partial class seeker_profile : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    int id;
    string seid;

    protected void Page_Load(object sender, EventArgs e)
    {
        id = Convert.ToInt32(Session["J_id"]);
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
       
       
       
        if (Session["seeker_name"] == null)
        {
            Response.Redirect("login.aspx");
        }
        else 
        {
            lbl_j.Text = Session["seeker_name"].ToString();
            seid=Session["s_eid"].ToString();
            pnl_pinfo.Visible = true;
            pnl_edu.Visible = false;
            pnl_exp.Visible = false;
            show();
        }

        con.Open();
        cmd = new SqlCommand("select company_name,job_role,job_location from apply_job where seeker_name='"+seid+"' ", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            GridView1.DataSource = dr;
            GridView1.DataBind();
            dr.Close();
            con.Close();
        }
        else
        {
            Label2.Text = "You Haven't Applied For Any Job Yet";
        }
        dr.Close();
        con.Close();
       
    }

    public void show()
    {
        con.Open();
        cmd = new SqlCommand("select * from seeker_detail where s_id='" + Convert.ToInt16(id) + "'", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                fullnm.Text = "<b> Name </b>: " + dr[3] + " " + dr[4];
                eid.Text = "<b> E-Mail ID </b>: " + dr[1].ToString();
                address.Text = "<b> Address </b>: " + dr[5].ToString();
                city.Text = "<b> City </b>: " + dr[6].ToString();
                contact_no.Text = "<b> Contact No </b>: " + dr[8].ToString();
                dob.Text = "<b> Date Of Birth </b>: " + dr[10].ToString();
            }
        }
        dr.Close();
        con.Close();
    }


    protected void btn_personal_Click(object sender, EventArgs e)
    {
        pnl_pinfo.Visible = true;
        pnl_edu.Visible = false;
        pnl_exp.Visible = false;
        show();
    }
    protected void btn_edu_Click(object sender, EventArgs e)
    {
        pnl_pinfo.Visible = false;
        pnl_edu.Visible = true;
        pnl_exp.Visible = false;

        con.Open();
        cmd = new SqlCommand("select * from seeker_edu_detail where s_id='" + Convert.ToInt16(id) + "' ", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                cource.Text = "<b> Cource </b>: " + dr[2];
                branch.Text = "<b> Branch </b>: " + dr[3];
                clgnm.Text = "<b> College Name </b>: " + dr[4].ToString();
                pre.Text = " <b> Percentage </b>: " + dr[7].ToString();
                skill.Text = "<b> Skills </b>: " + dr[8].ToString();
            }
        }
        else
        {
            cource.Text = " You haven't add education details yet .. !!";
            branch.Visible=false;
            clgnm.Visible=false;
            pre.Visible=false;
            skill.Visible=false;
        }
        dr.Close();
        con.Close();


    }
    protected void btn_exp_Click(object sender, EventArgs e)
    {
        pnl_pinfo.Visible = false;
        pnl_edu.Visible = false;
        pnl_exp.Visible = true;

        con.Open();
        cmd = new SqlCommand("select * from experiance_detail where s_id='" + Convert.ToInt16(id) + "'", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                job_pos.Text = "<b> Job Position </b>: " + dr[2];
                c_nm.Text = "<b> Company Name </b>: " + dr[3];
                loc.Text = "<b> Place </b>: " + dr[4].ToString();
                year.Text = " <b> Experience Years </b>: " + dr[5].ToString();
                desc.Text = "<b> Job Description </b>: " + dr[6].ToString();
            }
        }
        else
        {
            job_pos.Text = " You haven't add your experience details";
            c_nm.Visible = false;
            loc.Visible = false;
            year.Visible = false;
            desc.Visible = false;
        }
        dr.Close();
        con.Close();

    }


    protected void btn_update_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/update_seeker.aspx");
    }
    protected void Link_login_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
  }
