﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
 
    string s_nm;
    string resume_path;

    protected void Page_Load(object sender, EventArgs e)
    {
       
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        
            if (Session["seeker_name"] == null)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "msg", "msg();", true);
            }
            else
            {
                 apply();
                   
                    
                }
                
            
            
        
         
    }
    public void apply()
    {
        int id = Convert.ToInt32(Request.QueryString["id"]);
        s_nm = Session["seeker_name"].ToString();

        con.Open();

        cmd = new SqlCommand("select * from post_a_job where job_id='" + id + "' ", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                lbl_cnm.Text = dr[2].ToString();
                lbl_cid.Text = dr[0].ToString();
                lbl_jid.Text = dr[1].ToString();
            }
        }
        dr.Close();
        con.Close();

        con.Open();
        cmd = new SqlCommand("select * from post_a_job where job_id='" + id + "' ", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                lbl_loc.Text = dr[9].ToString();
                lbl_pos.Text = dr[5].ToString();
            }
        }
        dr.Close();
        con.Close();



   
    }
    protected void btn_apply_Click(object sender, EventArgs e)
    {
        
        con.Open();
        string nm = Session["seeker_name"].ToString();
        string eid = Session["s_eid"].ToString();
        HttpPostedFile pf = resume_upload.PostedFile;
        string r;
        r = pf.ContentType;

        string ext = System.IO.Path.GetExtension(resume_upload.PostedFile.FileName);

        if (ext == ".pdf")
        {
            resume_path = "~/seeker_resumes/" + nm + " .pdf";
            resume_upload.SaveAs(Server. MapPath("~/seeker_resumes/" +nm+ " .pdf"));
        }
        cmd = new SqlCommand("insert into apply_job (job_id,company_id,seeker_name,company_name,job_role,job_location,resume) values('"+lbl_jid.Text+"','"+lbl_cid.Text+"','" + eid + "','" + lbl_cnm.Text + "','" + lbl_pos.Text + "','" + lbl_loc.Text + "','" + resume_path + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();

        ScriptManager.RegisterStartupScript(this, GetType(), "apply", "apply();", true);
    }
}