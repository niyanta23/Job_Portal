﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        con.Open();
        if (Session["seeker_name"] == null && Session["c_name"]==null)
        {
            Response.Redirect("login.aspx");
        }
        else
        {
            if(Session["seeker_name"] ==null && Session["c_name"]!=null)
            {
                Response.Redirect("company_profile.aspx");
            }

            if (Session["seeker_name"] != null && Session["c_name"] == null)
            {
                Response.Redirect("seeker_profile.aspx");
            }
           
        }
    }
}