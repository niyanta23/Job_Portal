﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    static int sid = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        pnl_personal.Visible = true;
        pnl_edu.Visible = false;
        pnl_exp.Visible = false;
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
    }
   
    protected void btn_personal_Click(object sender, EventArgs e)
    {
        pnl_personal.Visible = true;
        pnl_edu.Visible = false;
        pnl_exp.Visible = false;
    }
    protected void btn_edu_Click(object sender, EventArgs e)
    {
        pnl_personal.Visible = false;
        pnl_edu.Visible = true;
        pnl_exp.Visible = false;
    }
    protected void btn_exp_Click(object sender, EventArgs e)
    {
        pnl_personal.Visible = false;
        pnl_edu.Visible = false;
        pnl_exp.Visible = true;
    }
    protected void btn_per_next_Click(object sender, EventArgs e)
    {
        pnl_personal.Visible = false;
        pnl_edu.Visible = true;
        pnl_exp.Visible = false;
    }
    protected void btn_edu_next_Click(object sender, EventArgs e)
    {
        pnl_personal.Visible = false;
        pnl_edu.Visible = false;
        pnl_exp.Visible = true;
    }
    public void ins_per()
    {
        con.Open();
        string date = DateTime.Now.Date.ToShortDateString();
        cmd = new SqlCommand("insert into seeker_detail(seeker_email_id,seeker_password,seeker_firstname,seeker_lastname,seeker_address,seeker_city,seeker_pincode,seeker_mo_no,seeker_gender,seeker_dob,seeker_registerdate) values('" + txt_eid.Text + "','" + txt_pwd.Text + "','" + txt_fnm.Text + "','" + txt_lnm.Text + "','" + txt_add.Text + "','" + txt_city.Text + "','" + txt_pin.Text + "','" + txt_mono.Text + "','" + RadioButtonList1.SelectedItem.ToString() + "','" + txt_dob.Text + "','" + date + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
    }
    public void get_id()
    {
        con.Open();
        cmd = new SqlCommand("select * from seeker_detail where seeker_email_id='" + txt_eid.Text + "' ", con);
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            if (dr.HasRows)
            {
                sid = Convert.ToInt32(dr[0]);
            }
        }
        con.Close();
    }
    public void ins_edu()
    {
        con.Open();
        cmd = new SqlCommand("insert into Seeker_Edu_detail(s_id,js_cource,js_branch,js_collegename,js_startingyear,js_endingyear,js_percentage,js_extraskill) values('" + sid + "','"  + txt_cource.Text + "','" + txt_branch.Text + "','" + txt_clgnm.Text + "','" + txt_startyr.Text + "','" + txt_endingyr.Text + "','" + txt_per.Text + "','" + txt_skill.Text + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        txt_cource.Text = "";
        txt_branch.Text = "";
        txt_clgnm.Text = "";
        txt_startyr.Text = "";
        txt_endingyr.Text = "";
        txt_per.Text = "";
        txt_skill.Text="";
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {       
        ins_per();
        get_id();
        ins_edu();
        get_id();   
        con.Open();
        cmd = new SqlCommand("insert into experiance_detail(s_id,exp_job_position,exp_company_name,exp_location,exp_year,exp_description) values('" + sid + "','" + txt_job_position.Text + "','" + txt_cmpy_nm.Text + "','" + txt_location.Text + "','" + txt_exp_year.Text + "','" + txt_desc.Text + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        txt_eid.Text = "";
        txt_pwd.Text = "";
        txt_fnm.Text = "";
        txt_lnm.Text = "";
        txt_add.Text = "";
        txt_city.Text = "";
        txt_pin.Text = "";
        txt_mono.Text = "";
        txt_dob.Text = "";
        Response.Redirect("login.aspx");
    }
  
    protected void exp_choice_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (exp_choice.SelectedIndex == 0)
        {
            btn_exp.Visible = false;
            btn_edu_next.Visible = false;
            pnl_exp.Visible = false;         
            btn_sbmt1.Visible = true;
        } 
    }
    protected void btn_sbmt1_Click(object sender, EventArgs e)
    {
        ins_per();
        get_id();
        ins_edu();
        Response.Redirect("login.aspx");
    }
}