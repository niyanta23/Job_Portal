﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    int id;

    protected void Page_Load(object sender, EventArgs e)
    {
        id = Convert.ToInt32(Session["c_id"]);
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
       
        if (!IsPostBack)
        {
            con.Open();
            cmd = new SqlCommand("select * from company_detail where company_id='" + Convert.ToInt32(id) + "' ", con);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txt_cnm.Text = dr[1].ToString();
                    txt_ceid.Text = dr[2].ToString();
                    txt_cpwd.Text = dr[3].ToString();
                    txt_cadd.Text = dr[4].ToString();
                    txt_ct.Text = dr[5].ToString();
                    txt_pin.Text = dr[6].ToString();
                    txt_mono.Text = dr[7].ToString();
                    txt_website.Text = dr[8].ToString();
                }
            }
            dr.Close();
            con.Close();
        
        }
       
       
    }


    protected void btn_update_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("update company_detail set company_name='" + txt_cnm.Text + "',company_email_id='" + txt_ceid.Text + "',company_password='" + txt_cpwd.Text + "',company_address='" + txt_cadd.Text + "',company_city='" + txt_ct.Text + "',company_pincode='" + txt_pin.Text + "',company_contact_no='" + txt_mono.Text + "',company_website='" + txt_website.Text + "' where company_id='" + Convert.ToInt32(Session["c_id"]) + "'", con);
        int n = cmd.ExecuteNonQuery();
        if (n > 0)
        {
            Response.Write("dfsdfd");
        }
        con.Close();
        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alertMessage();", true);
    }
}