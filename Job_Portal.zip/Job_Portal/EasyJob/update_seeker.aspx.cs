﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    int id;

    protected void Page_Load(object sender, EventArgs e)
    {
        id = Convert.ToInt32(Session["J_id"]);
        if(!IsPostBack)
        {
        pnl_personal.Visible = true;
        pnl_edu.Visible = false;
        pnl_exp.Visible = false;
        }
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
       

        if (!IsPostBack)
        {
            con.Open();
            cmd = new SqlCommand("select * from seeker_detail where s_id='" + id + "'", con);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txt_eid.Text = dr[1].ToString();
                    txt_pwd.Text = dr[2].ToString();
                    txt_fnm.Text = dr[3].ToString();
                    txt_lnm.Text = dr[4].ToString();
                    txt_add.Text = dr[5].ToString();
                    txt_city.Text = dr[6].ToString();
                    txt_pin.Text = dr[7].ToString();
                    txt_mono.Text = dr[8].ToString();
                    string g = dr[9].ToString();
                    if (g == "Male")
                    {
                        RadioButtonList1.SelectedIndex = 0;
                    }
                    else
                    {
                        RadioButtonList1.SelectedIndex = 1;
                    }

                    txt_dob.Text = dr[10].ToString();

                }
            }
            con.Close();

            con.Open();
            cmd = new SqlCommand("select * from seeker_edu_detail where s_id='" + id + "'", con);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txt_cource.Text = dr[2].ToString();
                    txt_branch.Text = dr[3].ToString();
                    txt_clgnm.Text = dr[4].ToString();
                    txt_startyr.Text = dr[5].ToString();
                    txt_endingyr.Text = dr[6].ToString();
                    txt_per.Text = dr[7].ToString();
                    txt_skill.Text = dr[8].ToString();
                }
            }
            con.Close();

            con.Open();
            cmd = new SqlCommand("select * from experiance_detail where s_id='" + id + "'", con);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txt_job_position.Text = dr[2].ToString();
                    txt_cmpy_nm.Text = dr[3].ToString();
                    txt_location.Text = dr[4].ToString();
                    txt_exp_year.Text = dr[5].ToString();
                    txt_desc.Text = dr[6].ToString();
                }
            }
            con.Close();



        }
        


    }
    protected void btn_personal_Click(object sender, EventArgs e)
{
          pnl_personal.Visible = true;
        pnl_edu.Visible = false;
        pnl_exp.Visible = false;
}
protected void btn_edu_Click(object sender, EventArgs e)
{
       pnl_personal.Visible = false;
        pnl_edu.Visible = true;
        pnl_exp.Visible = false;
}
protected void btn_exp_Click(object sender, EventArgs e)
{
    pnl_personal.Visible = false;
    pnl_edu.Visible = false;
    pnl_exp.Visible = true;
}
protected void btn_per_next_Click(object sender, EventArgs e)
{
    pnl_personal.Visible = false;
    pnl_edu.Visible = true;
    pnl_exp.Visible = false;
}
protected void btn_sbmt1_Click(object sender, EventArgs e)
{
    con.Open();
    cmd = new SqlCommand("update seeker_detail set seeker_email_id='" + txt_eid.Text + "',seeker_password='" + txt_pwd.Text + "',seeker_firstname='" + txt_fnm.Text + "',seeker_lastname='" + txt_lnm.Text + "',seeker_address='" + txt_add.Text + "',seeker_city='" + txt_city.Text + "',seeker_pincode='" + txt_pin.Text + "',seeker_mo_no='" + txt_mono.Text + "',seeker_gender='" + RadioButtonList1.SelectedItem + "',seeker_dob='" + txt_dob.Text + "'  where s_id='" + id + "'", con);
    cmd.ExecuteNonQuery();
    con.Close();

    con.Open();
    cmd = new SqlCommand("update seeker_edu_detail set js_cource='" + txt_cource.Text + "',js_branch='" + txt_branch.Text + "',js_collegename='" + txt_clgnm.Text + "',js_startingyear='" + txt_startyr.Text + "',js_endingyear='" + txt_endingyr.Text + "',js_percentage='" + txt_per.Text + "',js_extraskill='" + txt_skill.Text + "'  where s_id='" + id + "'", con);
    cmd.ExecuteNonQuery();
    con.Close();
    Response.Redirect("login.aspx");

    ScriptManager.RegisterStartupScript(this, GetType(), "update_msg", "update_msg();", true);
}
protected void btn_edu_next_Click(object sender, EventArgs e)
{
    pnl_personal.Visible = false;
    pnl_edu.Visible = false;
    pnl_exp.Visible = true;
}
protected void btn_cng_Click(object sender, EventArgs e)
{
    con.Open();
    cmd = new SqlCommand("update seeker_detail set seeker_email_id='" + txt_eid.Text + "',seeker_password='" + txt_pwd.Text + "',seeker_firstname='" + txt_fnm.Text + "',seeker_lastname='" + txt_lnm.Text + "',seeker_address='" + txt_add.Text + "',seeker_city='" + txt_city.Text + "',seeker_pincode='" + txt_pin.Text + "',seeker_mo_no='" + txt_mono.Text + "',seeker_gender='" + RadioButtonList1.SelectedItem + "',seeker_dob='" + txt_dob.Text + "'  where s_id='" + id + "'", con);
    cmd.ExecuteNonQuery();
    con.Close();

    con.Open();
    cmd = new SqlCommand("update seeker_edu_detail set js_cource='" + txt_cource.Text + "',js_branch='" + txt_branch.Text + "',js_collegename='" + txt_clgnm.Text + "',js_startingyear='" + txt_startyr.Text + "',js_endingyear='" + txt_endingyr.Text + "',js_percentage='" + txt_per.Text + "',js_extraskill='" + txt_skill.Text + "'  where s_id='" + id + "'", con);
    cmd.ExecuteNonQuery();
    con.Close();

    con.Open();
    cmd = new SqlCommand("update experiance_detail set exp_job_position='" + txt_job_position.Text + "',exp_company_name='" + txt_cmpy_nm.Text + "',exp_location='" + txt_location.Text + "',exp_year='" + txt_exp_year.Text + "',exp_description='" + txt_desc.Text + "'  where s_id='" + id + "'", con);
    cmd.ExecuteNonQuery();
    con.Close();
    Response.Redirect("login.aspx");
    ScriptManager.RegisterStartupScript(this, GetType(), "update_msg", "update_msg();", true);
}
protected void exp_choice_SelectedIndexChanged(object sender, EventArgs e)
{
    if (exp_choice.SelectedIndex == 0)
    {
        btn_exp.Visible = false;
        btn_edu_next.Visible = false;
        pnl_exp.Visible = false;
        btn_sbmt1.Visible = true;
    } 
}
}
