﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        con.Open();
        
    }

    protected void btn_signin_Click(object sender, EventArgs e)
    {
        Session.Clear();
        if (RadioButtonList1.SelectedValue == "Company")
        {
            cmd = new SqlCommand("select * from company_detail where company_email_id='" + txt_nm.Text + "' and company_password='"+txt_cpwd.Text+"'", con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["c_id"] = dr[0];
                Session["c_name"] = dr[1].ToString();
                Response.Redirect("company_profile.aspx");
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "errMessage", "errMessage();", true);
                txt_cpwd.Text = "";
            }
        }

        if (RadioButtonList1.SelectedValue == "JobSeeker")
        {
            cmd = new SqlCommand("select * from seeker_detail where seeker_email_id='" + txt_nm.Text + "' and seeker_password='" + txt_cpwd.Text + "'", con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["J_id"] = dr[0].ToString(); ;
                Session["s_eid"] = dr[1].ToString();
                Session["seeker_name"] = dr[3].ToString();
                
                Response.Redirect("seeker_profile.aspx");
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "errMessage", "errMessage();", true);
                txt_cpwd.Text = "";
            }
        }   
    }
   
    protected void btn_create_Click(object sender, EventArgs e)
    {
        if (RadioButtonList2.SelectedValue == "Company")
        {
            Response.Redirect("create_compny_acc.aspx");
        }
        else if (RadioButtonList2.SelectedValue == "JobSeeker")
        {
            Response.Redirect("creat_seeker_acc.aspx");
        }
        else
        {
            Lbl_erroe2.Text = "Please Select Who Are You .. !!!";
        }
    }
}