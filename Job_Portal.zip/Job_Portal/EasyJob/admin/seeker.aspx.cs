﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
public partial class admin_Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        con.Open();
        cmd = new SqlCommand("select s_id,seeker_email_id,seeker_firstname,seeker_city,seeker_mo_no from seeker_detail ", con);
        da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
        con.Close();

        con.Open();
        cmd = new SqlCommand("select seeker_name,company_name,job_role,job_location from apply_job", con);
        da = new SqlDataAdapter(cmd);
        DataTable dt1 = new DataTable();
        da.Fill(dt1);
        GridView2.DataSource = dt1;
        GridView2.DataBind();
        con.Close();


    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        con.Open();
        cmd = new SqlCommand("select s_id,seeker_email_id,seeker_firstname,seeker_city,seeker_mo_no from seeker_detail ", con);
        da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
        con.Close();

    }
    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView2.PageIndex = e.NewPageIndex;
        con.Open();
        cmd = new SqlCommand("select seeker_name,company_name,job_role,job_location from apply_job", con);
        da = new SqlDataAdapter(cmd);
        DataTable dt1 = new DataTable();
        da.Fill(dt1);
        GridView2.DataSource = dt1;
        GridView2.DataBind();
        con.Close();
    }
}