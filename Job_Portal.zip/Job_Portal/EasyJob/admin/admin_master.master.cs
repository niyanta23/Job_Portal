﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_admin_master : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["a_id"] != null)
        {
            cmpny.Visible = true;
            feed.Visible = true;
            seeker.Visible = true;
            logout.Visible = true;

        }
    }
    protected void login_Click(object sender, EventArgs e)
    {
        
        Response.Redirect("adlogin.aspx");

    }
    protected void cmpny_Click(object sender, EventArgs e)
    {
        Response.Redirect("cmpny.aspx");
    }
    protected void seeker_Click(object sender, EventArgs e)
    {
        Response.Redirect("seeker.aspx");
    }
    protected void job_Click(object sender, EventArgs e)
    {
        Response.Redirect("job.aspx");
    }
    protected void feed_Click(object sender, EventArgs e)
    {
        Response.Redirect("feedback.aspx");
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        seeker.Visible = false;
        cmpny.Visible = false;
        feed.Visible = false ;
        login.Visible = true;
        Response.Redirect("adlogin.aspx");

    }
}
