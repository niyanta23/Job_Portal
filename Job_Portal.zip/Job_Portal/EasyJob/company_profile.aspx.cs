﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
using System.IO;
using System.Web;
using System.Net;
public partial class company_profile : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    IDataAdapter da;
    String name;
    protected void Page_Load(object sender, EventArgs e)
    {

        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);

        
        

        con.Open();

        lbl_c.Text = Session["c_name"].ToString();
        int id = Convert.ToInt32(Session["c_id"]);
      
        cmd = new SqlCommand("select * from company_detail where company_id='" +Convert.ToInt32(id)+ "' ", con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                lbl_cnm.Text ="<b> Company Name </b>: "+ dr[1].ToString();
                lbl_ceid.Text ="<b> Company Email - ID </b>: " +dr[2].ToString();
                lbl_cpwd.Text ="<b> Password </b>: "+ dr[3].ToString();
                lbl_cadd.Text = "<b> Company Address </b>: "+dr[4].ToString();
                lba_ct.Text = "<b> Company City </b>: " +dr[5].ToString();
                lbl_pin.Text = "<b> Company Pincode </b>: "+dr[6].ToString();
                lbl_mno.Text = "<b> Contact Number </b>: "+dr[7].ToString();
                lbl_web.Text = "<b> Website </b>: "+dr[8].ToString();
            }
        }
        dr.Close();
        con.Close();

        con.Open();
        cmd=new SqlCommand("select role,job_category,required_skills,job_location,last_apply_date from post_a_job where company_id='"+id+"' order by job_id desc",con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            GridView1.DataSource = dr;
            GridView1.DataBind();
        }
        else
        {
            Label2.Text = "You Haven't Post Any Job Yet .. !";
        }
        dr.Close();
        con.Close();
        if (!IsPostBack)
        {
            con.Open();
            cmd = new SqlCommand("select seeker_name,job_role,resume from apply_job where company_name='" + Session["c_name"].ToString() + "'", con);
            da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView2.DataSource = ds;
            GridView2.DataBind();
            con.Close();
        }
       
    }
    protected void btn_update_Click(object sender, EventArgs e)
    {
        Response.Redirect("update_company.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
       
    }

   


   


  
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        LinkButton btn = (LinkButton)sender;
        string nm = btn.CommandArgument;
   
        String path = Server.MapPath(nm);
        WebClient client = new WebClient();
        Byte[] buffer = client.DownloadData(path);
        if (buffer != null)
        {
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-length", buffer.Length.ToString());
            Response.BinaryWrite(buffer);
        }

     
    }
}