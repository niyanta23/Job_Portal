﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        con.Open();
        
    }
    protected void btn_reset_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "Company")
        {
            cmd=new SqlCommand("update company_detail set company_password='"+ txt_cpwd.Text+"' where company_email_id='"+ txt_nm.Text+"' ",con);
            cmd.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, GetType(), "msg", "msg();", true);

        }
        if (RadioButtonList1.SelectedValue == "JobSeeker")
        {
            cmd = new SqlCommand("update seeker_detail set seeker_password='" + txt_cpwd.Text + "' where seeker_email_id='" + txt_nm.Text + "' ", con);
            cmd.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, GetType(), "msg", "msg();", true);

        }
   
    }
}