﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class admin_Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        con.Open();
    }
    protected void update_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("update Admin_login set admin_password='" + txt_pwd.Text + "' where admin_username='" + txt_eid.Text + "' ", con);
        cmd.ExecuteNonQuery();
        ScriptManager.RegisterStartupScript(this, GetType(), "msg", "msg();", true);
        con.Close();
    }
}