﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Web.Configuration;


public partial class Default2 : System.Web.UI.Page
{

    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;


    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        con.Open();

    }
    protected void btn_register_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("insert into company_detail(company_name,company_email_id,company_password,company_address,company_city,company_pincode,company_contact_no,company_website,company_entry_date) values('" + txt_cnm.Text + "','" + txt_ceid.Text + "','" + txt_cpwd.Text + "','" + txt_cadd.Text + "','" + txt_ct.Text + "','" + txt_pin.Text + "','" + txt_mono.Text + "','" + txt_website.Text + "','" + DateTime.Now.Date.ToShortDateString() + "')", con);
       cmd.ExecuteNonQuery();
       txt_cnm.Text = "";
       txt_cpwd.Text = "";
       txt_repwd.Text = "";
       txt_ct.Text = "";
       txt_mono.Text = "";
       txt_cadd.Text = "";
       txt_pin.Text = "";
       txt_website.Text = "";
       ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alertMessage();", true);  

       
      // Response.Redirect("login.aspx");
    }
}