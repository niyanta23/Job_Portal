﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
public partial class index : System.Web.UI.Page
{
    int  id1;
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        if (!IsPostBack)
        {
            con.Open();
            cmd = new SqlCommand("select j.role,j.job_location,c.company_id, c.company_name,j.job_category from company_detail c inner join post_a_job j on c.company_id=j.company_id order by j.job_id desc", con);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView2.DataSource = dt;
            GridView2.DataBind();
            con.Close();
        }
       
    }
   
    protected void btn_find_Click(object sender, EventArgs e)
    {
        lbl_search.Visible = true;
        con.Open();
        cmd = new SqlCommand("select j.role,j.job_location,c.company_id, c.company_name,j.job_category from company_detail c inner join post_a_job j on c.company_id=j.company_id where j.role='" + txt_role.Text + "' and j.job_category='" + dd1_category.SelectedItem + "' and j.job_location='" + txt_loc.Text + "'", con);
        da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        grid_srch.DataSource = dt;
        grid_srch.DataBind();
        con.Close();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("post_a_job.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("want_a_job.aspx");
    }
    protected void Link_login_Click(object sender, EventArgs e)
    {
           // Link_login.Text = "Logout";
            Response.Redirect("login.aspx");
    }  
    
    protected void btn_appply_Click(object sender, EventArgs e)
    {
        Button btn = sender as Button;
        id1 = Convert.ToInt32( btn.CommandArgument);
        Response.Redirect("apply.aspx?id=" + id1);
    }

}