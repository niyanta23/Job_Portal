﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    int com_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        con.Open();
        if (Convert.ToInt32(Session["c_id"])== 0)
        {
               ScriptManager.RegisterStartupScript(this, GetType(), "errMessage", "errMessage();", true);
        }
        
    }
    protected void btn_post_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("insert into post_a_job (company_id,company_name,job_category,required_skills,role,min_qualification,min_experiance,salary_scale,job_location,job_description,last_apply_date) values('" + Convert.ToInt32(Session["c_id"]) + "','" + Session["c_name"].ToString() + "','" + dd_category.SelectedValue + "','" + txt_skill.Text + "','" + txt_role.Text + "','" + txt_qual.Text + "','" + txt_exp.Text + "','" + txt_sal.Text + "','" + txt_loc.Text + "','" + txt_desc.Text + "','" + txt_dt.Text + "') ", con);
        cmd.ExecuteNonQuery();
        txt_skill.Text="";
        txt_role.Text="";
        txt_qual.Text="";
        txt_exp.Text="";
        txt_sal.Text="";
        txt_loc.Text="";
        txt_desc.Text="";
        txt_dt.Text="";
        Response.Redirect("company_profile.aspx");
        ScriptManager.RegisterStartupScript(this, GetType(), "infoMessage", "infoMessage();", true);

    }
    
    
}