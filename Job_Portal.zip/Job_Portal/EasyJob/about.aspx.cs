﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;



public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(WebConfigurationManager.ConnectionStrings["Easy_Job_ConnectionString"].ConnectionString);
        con.Open();       
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("insert into inbox (inbox_from,inbox_message,inbox_date) values('" + txt_eid.Text + "','" + txt_msg.Text + "','" + DateTime.Now.Date.ToShortDateString() + "')", con);
        cmd.ExecuteNonQuery();
        txt_eid.Text = "";
        txt_msg.Text = "";
       // Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "alert(' Feedback Sent SuccessFully ... !!');");
        ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alertMessage();", true);  

    }
}